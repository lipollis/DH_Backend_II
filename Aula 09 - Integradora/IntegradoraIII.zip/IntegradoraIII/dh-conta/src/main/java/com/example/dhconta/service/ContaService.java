package com.example.dhconta.service;

public interface ContaService {
    String getContaUsuario();
}
