package com.example.dhconta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhContaApplicationTests {

	@Test
	void contextLoads() {
	}

}
