package com.dh.jogos.dto;

import lombok.Data;

@Data
public class JogosDTO {
    private Long id;
    private String nome;
    private String nomeBiblioteca;
}
