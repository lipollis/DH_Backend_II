package com.dh.biblioteca.dto;

import lombok.Data;

@Data
public class BibliotecaDTO {
    private Long id;
    private String nome;
}
