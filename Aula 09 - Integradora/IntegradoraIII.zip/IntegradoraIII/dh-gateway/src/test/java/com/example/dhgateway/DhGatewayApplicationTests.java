package com.example.dhgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
