package com.example.dhusuario.service;

public interface UsuarioService {
    String getUsuario();
}
