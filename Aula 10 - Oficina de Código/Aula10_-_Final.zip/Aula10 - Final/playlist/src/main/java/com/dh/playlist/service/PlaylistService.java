package com.dh.playlist.service;

public interface PlaylistService {
    String getMusica(String genero);
}
