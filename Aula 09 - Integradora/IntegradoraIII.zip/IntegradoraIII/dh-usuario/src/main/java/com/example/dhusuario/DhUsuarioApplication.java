package com.example.dhusuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DhUsuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DhUsuarioApplication.class, args);
	}

}
